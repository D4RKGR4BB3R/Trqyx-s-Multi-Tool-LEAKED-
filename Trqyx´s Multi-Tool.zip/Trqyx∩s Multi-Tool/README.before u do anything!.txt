-------------------Trqyx´s Multi-Tool-------------------
Its not open source bc i dont like skids
--------------------------------------------------------
1) Open Installer-Setup then wait till its finished.

Once its finished it will automatic get to the multi tool.


-------------------IF U DID IT ONCE-------------------
still open Installer-Setup since it will update if its outdated and js better.
------------------------------------------------------
ENJOY!